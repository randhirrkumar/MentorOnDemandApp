import { Component, OnInit } from '@angular/core';
import { AdduserService } from '../adduser.service';
import { Role } from '../role';
import { User } from '../user';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css'],
})
export class AddUserComponent implements OnInit {
  user: User = new User();
  role: Role[];
  constructor(private adduserService: AdduserService) {}

  ngOnInit(): void {
    this.getAllRoles();
  }

  saveUser() {
    this.adduserService.saveUser(this.user).subscribe(
      (data) => {
        console.log(data);
      },
      (error) => console.log(error)
    );
  }

  private getAllRoles() {
    this.adduserService.getAllRoles().subscribe((data) => {
      this.role = data;
    });
  }

  onSubmit() {
    console.log(this.user);
    this.saveUser();
  }

  reloadCurrentPage() {
    window.location.reload();
  }
}
