import { Component, OnInit } from '@angular/core';
import { AddcourseService } from '../addcourse.service';
import { Course } from '../course';

@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.css'],
})
export class AddCourseComponent implements OnInit {
  course: Course = new Course();
  constructor(private addcourseService: AddcourseService) {}

  ngOnInit(): void {}

  saveCourse() {
    this.addcourseService.saveCourse(this.course).subscribe(
      (data) => {
        console.log(data);
      },
      (error) => console.log(error)
    );
  }

  onSubmit() {
    console.log(this.course);
    this.saveCourse();
  }

  reloadCurrentPage() {
    window.location.reload();
  }
}
