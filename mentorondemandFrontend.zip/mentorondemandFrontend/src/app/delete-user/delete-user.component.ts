import { Component, OnInit } from '@angular/core';
import { DeleteuserService } from '../deleteuser.service';
import { Role } from '../role';
import { User } from '../user';

@Component({
  selector: 'app-delete-user',
  templateUrl: './delete-user.component.html',
  styleUrls: ['./delete-user.component.css'],
})
export class DeleteUserComponent implements OnInit {
  users: User[];
  role: Role[];
  roleSelected: String;
  nameSelected: Number;
  nos: number;
  constructor(private deleteuserService: DeleteuserService) {}

  ngOnInit(): void {
    this.getAllRoles();
  }

  onRoleSelected(val: string) {
    console.log(val);
    this.deleteuserService.getUserByRoleId(val).subscribe((data) => {
      this.users = data;
    });
  }

  onNameSelected(vals: number) {
    console.log(vals);
    this.nos = vals;
  }

  private getAllRoles() {
    this.deleteuserService.getAllRoles().subscribe((data) => {
      this.role = data;
    });
  }

  deleteUser(nos: number) {
    this.deleteuserService.deleteUser(nos).subscribe((data) => {
      console.log(data);
    });
  }

  reloadCurrentPage() {
    window.location.reload();
  }
}
