import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Role } from './role';
import { User } from './user';

@Injectable({
  providedIn: 'root',
})
export class DeleteuserService {
  private baseURL = 'http://localhost:9191/admin/user/deleteuser';
  constructor(private httpClient: HttpClient) {}

  getAllUsers(): Observable<User[]> {
    return this.httpClient.get<User[]>('http://localhost:9191/admin/getuser');
  }

  getAllRoles(): Observable<Role[]> {
    return this.httpClient.get<Role[]>('http://localhost:9191/admin/getrole');
  }

  getUserByRoleId(val: string): Observable<User[]> {
    let param = new HttpParams().set('user_role', val);
    return this.httpClient.get<User[]>(
      'http://localhost:9191/admin/getuserbyroleid/' + val,
      { params: param }
    );
  }

  deleteUser(nos: number): Observable<Object> {
    return this.httpClient.delete(`${this.baseURL}/${nos}`);
  }
}
