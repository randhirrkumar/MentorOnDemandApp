export class Role {
  role_id: String;
  role_name: String;
}
