import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Role } from './role';
import { User } from './user';

@Injectable({
  providedIn: 'root',
})
export class AdduserService {
  private baseURL = 'http://localhost:9191/admin/user/adduser';
  constructor(private httpClient: HttpClient) {}

  saveUser(user: User): Observable<Object> {
    return this.httpClient.post(`${this.baseURL}`, user);
  }

  getAllRoles(): Observable<Role[]> {
    return this.httpClient.get<Role[]>('http://localhost:9191/admin/getrole');
  }
}
