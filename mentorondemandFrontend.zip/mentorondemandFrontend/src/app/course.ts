export class Course {
  course_id: number;
  course_name: string;
  course_description: string;
}
