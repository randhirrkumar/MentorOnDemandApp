import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddCourseComponent } from './add-course/add-course.component';
import { AddUserComponent } from './add-user/add-user.component';
import { AdminComponent } from './admin/admin.component';
import { DeleteCourseComponent } from './delete-course/delete-course.component';
import { DeleteUserComponent } from './delete-user/delete-user.component';

const routes: Routes = [
  { path: 'adduser', component: AddUserComponent },
  { path: 'deleteuser', component: DeleteUserComponent },
  { path: 'addcourse', component: AddCourseComponent },
  { path: 'deletecourse', component: DeleteCourseComponent },
  { path: 'admin', component: AdminComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
