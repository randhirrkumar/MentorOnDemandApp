import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Course } from './course';

@Injectable({
  providedIn: 'root',
})
export class DeletecourseService {
  private baseURL = 'http://localhost:9191/admin/course/deletecourse';
  constructor(private httpClient: HttpClient) {}

  getAllCourses(): Observable<Course[]> {
    return this.httpClient.get<Course[]>(
      'http://localhost:9191/admin/getcourse'
    );
  }

  deleteCourse(num: number): Observable<Object> {
    console.log('Hi the value is ' + num + '.');

    const deleteURL = 'http://localhost:9191/admin/course/deletecourse/' + num;
    return this.httpClient.delete(deleteURL);
  }
}
