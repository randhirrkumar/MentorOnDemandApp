import { Component, OnInit } from '@angular/core';
import { Course } from '../course';
import { DeletecourseService } from '../deletecourse.service';

@Component({
  selector: 'app-delete-course',
  templateUrl: './delete-course.component.html',
  styleUrls: ['./delete-course.component.css'],
})
export class DeleteCourseComponent implements OnInit {
  course: Course[];
  courseSelected: Number;
  num: number;

  constructor(private deletecourseService: DeletecourseService) {}

  ngOnInit(): void {
    this.getAllCourses();
  }

  onCourseSelected(val: number) {
    console.log(val);
    this.num = val;
  }

  private getAllCourses() {
    this.deletecourseService.getAllCourses().subscribe((data) => {
      this.course = data;
    });
  }

  deleteCourse(num: number) {
    console.log(num);
    // if (confirm('Are you sure to delete this course?'))
    this.deletecourseService.deleteCourse(num).subscribe((data) => {
      // alert('Record deleted successfully');
    });
  }

  reloadCurrentPage() {
    window.location.reload();
  }
}
