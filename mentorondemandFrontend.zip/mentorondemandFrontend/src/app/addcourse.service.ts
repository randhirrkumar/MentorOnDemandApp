import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Course } from './course';

@Injectable({
  providedIn: 'root',
})
export class AddcourseService {
  private baseURL = 'http://localhost:9191/admin/course/addcourse';
  constructor(private httpClient: HttpClient) {}

  saveCourse(course: Course): Observable<Object> {
    return this.httpClient.post(`${this.baseURL}`, course);
  }
}
